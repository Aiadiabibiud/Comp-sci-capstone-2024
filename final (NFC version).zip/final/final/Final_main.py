# prebuilt modules
import tkinter as tk
from tkinter import ttk
import ttkbootstrap
import sqlite3
import time
from PIL import Image, ImageTk
from datetime import datetime

# custom files
import view
import popup
import Arduino_in

def first():
    def okay():
        def set():
            title.pack_forget()
            row1.pack_forget()
            row2.pack_forget()
            ok.pack_forget()
            lab.pack()
        def scan():
            return Arduino_in.scan()
        lab = ttk.Label(window, text = 'Scan nfc for new user')
        name = nameField.get()
        salary = salaryField.get()
        set()
        id = scan()
        cursor.execute("INSERT INTO users VALUES (?, ?, ?, True, True, '00:00')", (id, name, salary),)
        cursor.execute("INSERT INTO timesheet VALUES (?, NULL)", (id,),)
        cursor.execute("INSERT INTO schedule VALUES (?, '')", (id,),)
        connection.commit()
        lab.pack_forget()
        window.geometry('500x500')
        window.title('Computer science capstone 2024')
        pack_scan()
    clear_scan()
    title = ttk.Label(window, text = 'New user', font = 90)
    title.pack()
    window.geometry('300x300')
    row1 = ttk.Frame(window)
    row2 = ttk.Frame(window)
    row1.pack()
    row2.pack()
    nameLab = ttk.Label(row1, text = 'name: ')
    nameField = ttk.Entry(row1)
    #idLab = ttk.Label(row1, text = 'ID: ')
    #idField = ttk.Entry(row1)
    nameLab.pack(side = 'left')
    nameField.pack(side = 'left')
    #idLab.pack(side = 'left')
    #idField.pack(side = 'left')
    salaryLab = ttk.Label(row2, text = 'Salary: ')
    salaryField = ttk.Entry(row2)
    salaryLab.pack(side = 'left')
    salaryField.pack(side = 'left')
    ok = ttk.Button(window,text = 'Scan NFC to assign to new user', command = okay)
    ok.pack(side = 'bottom', pady = 5)

def pack_scan():
    nfc_image_label.pack()
    nfc_label.pack(pady = 5)
    login_frame.pack(pady = 5)
    scanButton.pack()
    #login(Arduino_in.scan())
    #login_label.pack(side = 'left')
    #login_field.pack(side = 'left')

def clear_scan():
    nfc_image_label.pack_forget()
    nfc_label.pack_forget()
    login_frame.pack_forget()
    login_label.pack_forget()
    scanButton.pack_forget()
    #login_field.pack_forget()

def pack_main():
    mainCanvas.pack()
    signInOutButton.place(x = 130, y = 200)
    viewShiftsButton.place(x = 270, y = 200)
    logoutButton.pack(side = tk.BOTTOM)

def clear_main():
    mainCanvas.pack_forget()
    signInOutButton.place_forget()
    viewShiftsButton.place_forget()
    logoutButton.pack_forget()
    check = cursor.execute('SELECT admin FROM users WHERE loggedIn = True').fetchall()
    clear_admin()

def login():
    #print(event)
    id = Arduino_in.scan()
    clear_scan()
    cursor.execute('UPDATE users SET loggedIn = ? WHERE id = ?',
                   (True, id))
    rows = cursor.execute('SELECT name FROM users WHERE loggedIn = True').fetchall()
    #print(rows)
    update_log()
    pack_main()
    adm = cursor.execute('SELECT admin FROM users WHERE loggedIn = True').fetchall()
    if len(adm) > 0:
        if adm[0][0] == 1:
            pack_admin()

def pack_admin():
    viewUsersButton.place(x = 165, y = 250)
    viewScheduleButton.place(x = 270, y = 250)

def clear_admin():
    viewUsersButton.place_forget()
    viewScheduleButton.place_forget()
    
def update_log():
    rows = cursor.execute("SELECT name FROM users WHERE loggedIn = True"
                          ).fetchall()
    if rows:
        log.set(f"User: {rows[0][0]}")
        logged_in_label.pack(side = tk.BOTTOM)
    else:
        log.set('')
        logged_in_label.pack_forget()
    connection.commit()

def viewUsers():
    view.viewUsers()

def signInOut():
    hrs = ''
    mns = ''
    loggedId = cursor.execute('SELECT id FROM users WHERE loggedIn = True').fetchall()
    loggedId = int(loggedId[0][0])
    #print(loggedId)
    #print(type(loggedId))
    loggedName = cursor.execute('SELECT name FROM users WHERE loggedIn = True').fetchall()
    loggedName = loggedName[0][0]
    sign = cursor.execute('SELECT timeIn FROM timesheet WHERE id = ?', (loggedId,),).fetchall()
    if not sign[0][0]:
        sign = False
        cursor.execute('UPDATE timesheet SET timeIn = ? WHERE id = ?', (getTime(), loggedId,),)
        connection.commit()
    else:
        sign = True
        timeIn = cursor.execute('SELECT timeIn FROM timesheet WHERE id = ?', (loggedId,),).fetchall()[0][0]
        # print(timeIn)
        timeInH = int(timeIn.split(':')[0])
        timeInM = int(timeIn.split(':')[1])
        cursor.execute('UPDATE timesheet SET timeIn = NULL WHERE id = ?', (loggedId,),)
        totH = int(getTime().split(':')[0]) - timeInH
        totM = int(getTime().split(':')[1]) - timeInM
        hours = cursor.execute('SELECT hours FROM users WHERE id = ?', (loggedId,),).fetchall()[0][0]
        hours = hours.split(':')
        hrs = totH
        mns = totM
        totH = int(hours[0]) + totH
        totM = int(hours[1]) + totM
        if totM > 60:
            totM = totM-60
            totH += 1
        if totM < 10:
            totM = '0'+str(totM)
        hours = [str(totH), str(totM)]
        hours = ':'.join(hours)
        cursor.execute('UPDATE users SET hours = ? WHERE id = ?',(hours, loggedId,),)
        connection.commit()
        test = cursor.execute('SELECT hours FROM users WHERE id = ?', (loggedId,),).fetchall()
        # print(test)
    popup.signCon(loggedName, sign, style, hrs, mns)

def getTime():
    time = (str(datetime.now()).split(' '))[1]
    time = time.split('.')[0]
    time = time.split(':')[0:2]
    time = ':'.join(time)
    #print(time)
    return time

def getDate():
    date = (str(datetime.now()).split(' '))[0]
    return date

def viewShifts():
    view.viewShifts()

def viewSchedule():
    view.viewSchedule(style)

def logout():
    cursor.execute("UPDATE users SET loggedIn = False")
    #rows = cursor.execute('SELECT name, admin FROM users WHERE loggedIn = True').fetchall()
    #print(rows)
    update_log()
    clear_main()
    pack_scan()

connection = sqlite3.connect("capDat.db")
cursor = connection.cursor()
#making tables in database
try:
    cursor.execute('CREATE TABLE users (id INTEGER, name TEXT, salary INTEGER, admin BOOLEAN, loggedIn BOOLEAN, hours TEXT)')
    # id, name, salary, admin, loggedIn, hours
    connection.commit()
    #cursor.execute("INSERT INTO users VALUES (1, 'Aidan', 0, True, False, '10:00')")
    #cursor.execute("INSERT INTO users VALUES (2, 'Test', 20, False, False, '00:00')")
    rows = cursor.execute('SELECT id, name, salary, admin, loggedIn, hours FROM users'
                      ).fetchall()
    #print(rows)
except:
    pass
try:
    cursor.execute('CREATE TABLE timesheet (id INTEGER, timeIn TEXT)')
except:
    pass
try:
    cursor.execute('CREATE TABLE schedule (id INTEGER, shifts text)')
    connection.commit()
except:
    pass

cursor.execute("UPDATE users SET loggedIn = False")
connection.commit()

users = cursor.execute('SELECT id FROM users').fetchall()
timesheet = cursor.execute('SELECT id, timeIn FROM timesheet').fetchall()
schedule = cursor.execute('SELECT id FROM schedule').fetchall()
if len(timesheet) == 0:
    for user in users:
        cursor.execute('INSERT INTO timesheet VALUES (?, NULL)', (user))
    connection.commit()
if len(schedule) == 0:
    #for user in users:
        # print(user)
        #cursor.execute("INSERT INTO schedule VALUES (?, ?)", (user[0], '6/7/2024-16:30-22:00|6/9/2024-16:30-22:00'),)
    connection.commit()
shifts = cursor.execute('SELECT shifts FROM schedule').fetchall()
# print(shifts)

# print(timesheet)

# windows & window setup
window = tk.Tk()
window.title('Computer science capstone 2024')
window.geometry('580x500')
style = ttkbootstrap.Style(theme='superhero')

# widget setups
image = Image.open('''./NFC.png''')
image = image.resize((540,300), resample=3)
image = ImageTk.PhotoImage(image)

#Tkinter variables
log = tk.StringVar()

# widgets
# scan screen widgets
nfc_image_label = ttk.Label(window, image=image)
nfc_label = ttk.Label(window, text = 'Scan NFC card / chip', font = ('arial, 24'))
login_frame = ttk.Frame(window)
scanButton = ttk.Button(window, text = 'Log in with NFC', command = login)
# login_field = ttk.Entry(login_frame)
login_label = ttk.Label(login_frame, text = "ID: ")

# main window widgets
mainCanvas = tk.Canvas(window, background='white', width = 500, height = 400)
logoutButton = ttk.Button(window, text = 'log out', command = logout)
signInOutButton = ttk.Button(mainCanvas, text = 'sign in / sign out', command = signInOut)
viewShiftsButton = ttk.Button(mainCanvas, text = 'view shifts', command = viewShifts)
# admin widgets
viewUsersButton = ttk.Button(mainCanvas, text = 'view users', command = viewUsers)
viewScheduleButton = ttk.Button(mainCanvas, text = 'view schedule', command = viewSchedule)

# widget packing
logged_in_label = ttk.Label(window, textvariable=log)
pack_scan()
logged_in_label.pack()
# login_field.bind("<Return>", lambda event: login(login_field.get()))
# check for users
test = cursor.execute('SELECT id FROM users').fetchall()
if len(test) == 0:
    first()
window.mainloop()