import tkinter as tk
from tkinter import ttk
#import ttkbootstrap
import sqlite3
#import serial.tools.list_ports as stlp
#import serial
import os

connection = sqlite3.connect('../capDat.db')
cursor = connection.cursor()

#cursor.execute('CREATE TABLE users (id INTEGER, name TEXT, salary INTEGER, admin BOOLEAN, loggedIn BOOLEAN, hours INTEGER)')
# id, name, salary, admin, loggedIn, hours
connection.commit()
cursor.execute("INSERT INTO users VALUES (1, 'Aidan', 0, True, False, 10)")
cursor.execute("INSERT INTO users VALUES (2, 'Test', 20000, False, False, 0)")
rows = cursor.execute('SELECT id, name, salary, admin, loggedIn, hours FROM users'
                    ).fetchall()
connection.commit()
print(rows)
connection.commit()