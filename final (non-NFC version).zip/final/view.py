import tkinter as tk
from tkinter import ttk
import sqlite3
import ttkbootstrap
import popup
import sqlite3
from PIL import Image, ImageTk
from datetime import datetime

def viewShifts():
    def okay():
        window.destroy()
    connection = sqlite3.connect('capDat.db')
    cursor = connection.cursor()
    #print('clear')
    window = tk.Toplevel()
    window.geometry('300x400')
    window.title('your shifts')
    ok = ttk.Button(window, text = 'ok', command = okay)
    table = ttk.Treeview(window, columns=('date', 'start', 'end'))
    table.column('#0', anchor = 'w', width = 0)
    table.column('date', anchor = 'w', width = int(300/3))
    table.column('start', anchor = 'w', width = int(300/3))
    table.column('end', anchor = 'w', width = int(300/3))
    table.heading('date', text='Date', anchor='w')
    table.heading('start', text = 'Start Time', anchor='w')
    table.heading('end', text = 'End Time', anchor = 'w')
    table.pack()
    ok.pack()
    date = str(datetime.now()).split('-')
    id = cursor.execute('SELECT id FROM users WHERE loggedIn = True').fetchall()[0][0]
    year = int(date[0])
    month = int(date[1])
    day = int(date[2].split(' ')[0])
    shifts = cursor.execute('SELECT shifts FROM schedule WHERE id = ?', (id,),).fetchall()[0][0]
    shifts = shifts.split('|')
    i=0
    for shift in shifts:
        i+=1
        sDate = shift.split('-')[0]
        sYear = int(sDate.split('/')[0])
        sMonth = int(sDate.split('/')[1])
        sDay = int(sDate.split('/')[2])
        a = year > sYear
        b = (month > sMonth) and (year == sYear)
        c = (day > sDay) and (month == sMonth) and (year == sYear)
        if a or b or c:
            vls = shift.split('-')
            vls = [vls[0], vls[1], vls[2]]
            table.insert(parent = '', index='end', iid = i, values = vls)

    window.mainloop()

def viewUsers():
    def view_unpack():
        table.pack_forget()
        addUserButton.pack_forget()

    def addUser():
        def dataEntry():
            def finish():
                def popup(name):
                    popup.newCon(name)
                admin = admBool.get()
                name = nameIn.get()
                tst = cursor.execute('SELECT name FROM users').fetchall()
                for i in range(len(tst)):
                    tst[i] = tst[i][0]
                    tst[i] = tst[i][0:len(name)]
                if name in tst:
                    name = name+f"({int(tst.count(name))})"
                salary = salaryIn.get()
                # popup(name)
                cursor.execute("INSERT INTO users VALUES (?, ?, ?, ?, False, '00:00')", (id, name, salary, admin),)
                cursor.execute("INSERT INTO timesheet VALUES (?, NULL)",(id,),)
                cursor.execute("INSERT INTO schedule VALUES (?, '')", (id,),)
                connection.commit()
                newUser = cursor.execute("SELECT name, salary, hours FROM users WHERE id = ?", (id,),).fetchall()
                numUsers = len(cursor.execute("SELECT id FROM users").fetchall())
                newUser = list(newUser[0])
                newUser.append('$0.0')
                table.insert(parent='', index='end', iid = numUsers, values = newUser)

                nameIn.pack_forget()
                nameLab.pack_forget()
                salaryIn.pack_forget()
                salaryLab.pack_forget()
                row1.pack_forget()

                adm.pack_forget()
                conf.pack_forget()

                window.geometry('500x500')
                window.title('user view')

                table.pack()
                payoutButton.pack()
                addUserButton.pack(side = 'bottom', pady = 5)

            id = id_field.get()
            nfc_image_label.pack_forget()
            nfc_label.pack_forget()
            id_field.pack_forget()
            next.pack_forget()
            row1 = tk.Frame(window)
            row1.pack(pady = 30)

            name = tk.StringVar()
            nameIn = ttk.Entry(master=row1, textvariable=name)
            nameLab = ttk.Label(master=row1, text = 'name: ', font = 20)
            nameLab.pack(side = 'left', padx = 5)
            nameIn.pack(side = 'left', padx = 5)
            salary = tk.StringVar()
            salaryIn = ttk.Entry(master=row1, textvariable=salary)
            salaryLab = ttk.Label(master=row1, text = 'Salary / hour: ', font = 20)
            salaryLab.pack(side = 'left', padx = 5)
            salaryIn.pack(side = 'left', padx = 5)
            admBool = tk.BooleanVar()
            adm = ttk.Checkbutton(window, text = 'make user administrator?', 
                                  variable=admBool)
            adm.pack(pady = 15)
            conf = ttk.Button(window, text = 'Create user', command = finish)
            conf.pack(pady = 15)

        view_unpack()
        window.title('New user')
        window.geometry('450x200')
        image = Image.open('''./NFC.png''')
        image = image.resize((400,400), resample=2)
        image = ImageTk.PhotoImage(image)
        nfc_image_label = ttk.Label(window, image=image, style = 'superhero')
        nfc_label = ttk.Label(window, text = 'Scan NFC card / chip to assign to new user', 
                              font = ('arial, 15'), style = 'superhero')
        nfc_image_label.pack()
        nfc_label.pack()
        payoutButton.pack_forget()
        # manual ID imput for testing purpouses
        id_field = ttk.Entry(window)
        id_field.pack(pady = 5)
        next = ttk.Button(window, text = 'next', command = dataEntry)
        next.pack(pady = 5)

    def payout():
        vals = cursor.execute("SELECT name FROM users").fetchall()
        cursor.execute("UPDATE users SET hours = '00:00'")
        for i in range(len(vals)):
            edit = list(table.item(i, 'values'))
            edit[3] = '$0.0'
            table.item(i, values = edit)
        connection.commit()
        popup.payCon(vals)

    connection = sqlite3.connect('capDat.db')
    cursor = connection.cursor()
    window = tk.Toplevel()
    window.geometry('500x500')
    window.title('User view')
    #style.theme_use('superhero')

    addUserButton = ttk.Button(window, text = 'add user', command = addUser, style='superhero')
    payoutButton = ttk.Button(window, text = 'pay employees', command = payout)
    addUserButton.pack(side = tk.BOTTOM)
    table = ttk.Treeview(window, style = 'superhero')

    # define columns
    table['columns'] = ("Name", "Salary", "Hours", "Pay")
    # Format columns
    table.column('#0', width = 0, minwidth = 25)
    table.column('Name', anchor = 'w', width = int(450/5))
    table.column('Salary', anchor = 'w', width = int(450/5))
    table.column('Hours', anchor = 'w', width = int(450/5))
    table.column('Pay', anchor = 'w', width = int(450/5))
    # create headings
    table.heading('#0', text = '', anchor = 'w')
    table.heading('Name', text = 'Name', anchor = 'w')
    table.heading('Salary', text = 'Salary ($/hr)', anchor='w')
    table.heading('Hours', text = "Time Unpaid", anchor = 'w')
    table.heading('Pay', text = "Pay due", anchor = 'w')

    # adding data
    users = cursor.execute('SELECT name, salary, hours FROM users').fetchall()
    for i in range(len(users)):
        time = users[i][2]
        hours = int(time.split(':')[0])
        mins = int(time.split(':')[1])
        time = hours+(mins/60)
        users[i] = list(users[i])
        users[i].append('$'+str(time*users[i][1]))
    for i in range(len(users)):
        table.insert(parent='', index='end', iid = i, values = users[i])
    table.pack()
    payoutButton.pack(pady = 10)         

    window.mainloop()

def viewSchedule(style):
    connection = sqlite3.connect('capdat.db')
    cursor = connection.cursor()
    def schedule():
        def ret():
            row1.pack_forget()
            row2.pack_forget()
            row3.pack_forget()
            confirmBut.pack_forget()
            returnBut.pack_forget()
            window.geometry('500x300')
            table.pack()
            scheduleButton.pack()
        def conf():
            name = userVal.get()
            start = ''
            sh = shVal.get()
            sm = smVal.get()
            eh = ehVal.get()
            em = emVal.get()
            if sh < 10:
                sh = '0'+str(sh)
            else:
                sh = str(sh)

            if sm < 10:
                sm = '0'+str(sm)
            else:
                sm = str(sm)

            if eh < 10:
                eh = '0'+str(eh)
            else:
                eh = str(eh)

            if em < 10:
                em = '0'+str(em)
            else:
                em = str(em)
            #print(userVal.get())
            id = cursor.execute('SELECT id FROM users WHERE name = ?', (name,),).fetchall()[0][0]
            #print(id)
            pre = cursor.execute('SELECT shifts FROM schedule WHERE id = ?', (id,),).fetchall()[0][0]
            # print(pre)
            new = f'|{monVal.get()}/{dayVal.get()}/{yearVal.get()}-{sh}:{sm}-{eh}:{em}'
            shfts = pre+new
            if shfts[0] == '|':
                shfts = shfts[1:]
            cursor.execute('UPDATE schedule SET shifts = ? WHERE id = ?', (shfts, id,),)
            userVal.set('')
            shVal.set(0)
            smVal.set(0)
            ehVal.set(0)
            emVal.set(0)
            test = cursor.execute('SELECT shifts FROM schedule').fetchall()
            ct = 0
            for i in range(len(test)):
                test[i] = test[i][0]
            for i in range(len(test)):
                if test[i]:
                    ct+=(test[i].count('|')+1)
            table.insert(parent = '', index = 'end', iid = ct, 
                         values = (name, f'{monVal.get()}/{dayVal.get()}/{yearVal.get()}', f'{sh}:{sm}', f'{eh}:{em}'))
        
        window.geometry('700x300')
        table.pack_forget()
        scheduleButton.pack_forget()
        users = cursor.execute("SELECT name FROM users").fetchall()
        for i in range(len(users)):
            users[i]=users[i][0]
        row1 = ttk.Frame(window)
        row1.pack(pady = 10)
        row2 = ttk.Frame(window)
        row2.pack(pady = 10)
        row3 = ttk.Frame(window)
        row3.pack(pady = 10)

        # print(datetime.now())

        userVal = tk.StringVar()
        userButton = ttk.Combobox(row1, textvariable=userVal, values = users)
        userLab = ttk.Label(row1, text = 'User: ')
        userLab.pack(side = 'left')
        userButton.pack(side = 'left')
        monVal = tk.IntVar(value = int(str(datetime.now()).split('-')[1]))
        mon = ttk.Spinbox(row2, values = list(range(1, 13)), textvariable=monVal)
        monLab = ttk.Label(row2, text = 'month: ')
        monLab.pack(side = 'left')
        mon.pack(side = 'left')
        dayVal = tk.IntVar(value = int(str(datetime.now()).split('-')[2].split(' ')[0]))
        day = ttk.Spinbox(row2, values = list(range(1, 31)), textvariable=dayVal)
        dayLab = ttk.Label(row2, text = 'day:')
        dayLab.pack(side = 'left')
        day.pack(side = 'left')
        now = int(str(datetime.now()).split('-')[0])
        yearVal = tk.IntVar(value = int(str(datetime.now()).split('-')[0]))
        year = ttk.Combobox(row2, values = list(range(now, now+10)), textvariable=yearVal)
        yearLab = ttk.Label(row2, text = 'year: ')
        yearLab.pack(side = 'left')
        year.pack(side = 'left')

        startLab = ttk.Label(row3, text = 'Start: ')
        shVal = tk.IntVar()
        startH = ttk.Combobox(row3, values = list(range(23)), textvariable=shVal)
        startC = ttk.Label(row3, text = ':')
        smVal = tk.IntVar()
        startM = ttk.Combobox(row3, values = list(range(59)), textvariable=smVal)
        endLab = ttk.Label(row3, text = 'End: ')
        ehVal = tk.IntVar()
        endH = ttk.Combobox(row3, values = list(range(23)), textvariable=ehVal)
        endC = ttk.Label(row3, text = ':')
        emVal = tk.IntVar()
        endM = ttk.Combobox(row3, values = list(range(59)), textvariable=emVal)

        startLab.pack(side = 'left')
        startH.pack(side = 'left')
        startC.pack(side = 'left')
        startM.pack(side = 'left')
        endLab.pack(side = 'left')
        endH.pack(side = 'left')
        endC.pack(side = 'left')
        endM.pack(side = 'left')

        confirmBut = ttk.Button(window, text = 'Schedule shift', command = conf)
        returnBut = ttk.Button(window, text = 'return to schedule', command = ret)
        confirmBut.pack(pady=5)
        returnBut.pack(pady=5)
        # print(datetime.now())

    window = tk.Toplevel()
    window.geometry('500x300')
    window.title('schedule view')
    style.theme_use('superhero')
    table = ttk.Treeview(window, style = 'superhero', columns=('user', 'date', 'start', 'end'))
    table.column('#0', anchor='w', width=0)
    table.column('user', anchor='w', width = int(500/4))
    table.column('date', anchor = 'w', width = int(500/4))
    table.column('start', anchor='w', width = int(500/4))
    table.column('end', anchor='w', width = int(500/4))
    table.heading('user', text = 'Worker', anchor = 'w')
    table.heading('date', text = 'Date', anchor = 'w')
    table.heading('start', text = 'Shift start', anchor = 'w')
    table.heading('end', text = 'Shift end', anchor = 'w')
    scheduleButton = ttk.Button(window, text = 'Schedule shifts', command = schedule)
    # adding data
    vals = cursor.execute('SELECT id, shifts FROM schedule').fetchall()
    if len(vals) > 0:
        k=0
        i=0
        for i in range(len(vals)):
            shifts = vals[i][1].split('|')
            for j in range(len(shifts)):
                k+=1
                shift = shifts[j].split('-')
                user = [vals[i][0]]
                user = [cursor.execute('SELECT name FROM users WHERE id = ?', (user)).fetchall()[0][0]]
                info = user+shift
                if len(info) > len(user)+1:
                    table.insert(parent = '', index = 'end', iid = k, values = info)
                    print(f'{k}')
        
    table.pack()
    scheduleButton.pack()
    window.mainloop()