import tkinter as tk
from tkinter import ttk
#import ttkbootstrap
import sqlite3
#import serial.tools.list_ports as stlp
#import serial
import os

connection = sqlite3.connect('../capDat.db')
cursor = connection.cursor()
loggedId = 1
sign = cursor.execute('SELECT timeIn FROM timesheet WHERE id = ?', (loggedId)).fetchall()
print(sign)
#connection.commit()