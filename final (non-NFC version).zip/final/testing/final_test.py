import tkinter as tk
from tkinter import ttk
import ttkbootstrap
import sqlite3
import serial.tools.list_ports as stlp
import serial
import os

window = tk.Tk()

style = ttkbootstrap.Style(theme='superhero')

mainCanvas = tk.Canvas(window, width = 580, height = 400, background='red')
mainCanvas.pack()

window.mainloop()