# prebuilt modules
import tkinter as tk
from tkinter import ttk
import ttkbootstrap



def signCon(name, in_out, style, hours, mins):
    def quit():
        info.destroy()
    
    info = tk.Toplevel()
    info.geometry('300x100')

    style = style.theme_use('superhero')

    #user = cursor.execute("SELECT name FROM users WHERE loggedIn = True").fetchall()
    # change to id later
    ok = ttk.Button(info, text='ok', command = quit, style='superhero')
    if in_out:
        msg = f'{name} signed out; you worked {hours} hours and {mins} minute(s)'
    else:
        msg = f'{name} signed in'
    message = ttk.Label(info, text = msg, style='superhero')
    message.pack()
    ok.pack()
    info.mainloop()

def newCon(name):
    window = tk.Toplevel()
    window.title('New user created')
    window.geometry('100x100')
    ok = ttk.Button(window, text = 'ok', command = lambda: window.destroy())
    label = ttk.Label(window, text = f'New user {name}, created successfully')
    label.pack()
    ok.pack()

    window.mainloop()

def payCon(vals):
    def okay():
        window.destroy()
    window = tk.Toplevel()
    window.geometry('300x150')
    window.title('Pay users')
    lab = ttk.Label(window, text = 'All users paid out')
    ok = ttk.Button(window, text = 'ok', command = okay)
    lab.pack()
    ok.pack()
    window.mainloop()