import tkinter as tk
from tkinter import ttk
import ttkbootstrap
import sqlite3
import serial.tools.list_ports as stlp
import serial
import os

connection = sqlite3.connect('C:\\Users\\340930908\\Documents\\Comp-Sci 2024\\Python\\Capstone\\final\\capDat.db')
cursor = connection.cursor()
cursor.execute("UPDATE users SET loggedIn = ? WHERE name = ?",
               (True, 'Aidan'))
rows = cursor.execute('SELECT id, name, salary, admin FROM users'
                      ).fetchall()
print(rows)
#connection.commit()