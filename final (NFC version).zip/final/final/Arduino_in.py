import serial.tools.list_ports as stlp
import serial
import time
def scan():
    ports = stlp.comports()
    serialInst  = serial.Serial()

    portList = []
    for port in ports:
        portList.append(str(port))
        #print(str(port))

    val = str(port)[-2]

    portVar = ''

    for x in range(len(portList)):
        if portList[x].startswith("COM"+str(val)):
            portVar = "COM"+str(val)
            #print(portList[x])
            break

    if not portVar:
        print('Port not found')

    serialInst.baudrate = 115200
    serialInst.port = portVar
    serialInst.open()


    if not serialInst.in_waiting:
        packet = serialInst.readline()
        packet = str(packet.decode('utf'))
        packet = packet.split(' ')
        packet = ('').join(packet)
        packet = packet.split('0x')
        packet = ('').join(packet)
        packet = int(packet, 16)
        return packet